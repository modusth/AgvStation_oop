const long    timeSendHc12  = 500; 
String        lastMessage   = "";

String        strRfData = "";
byte          cntRfData = 0;
bool          unReadRfPackage = false;

#define maxMessage 10
byte    availableMessageCount = 0;
String  message[maxMessage];
byte    arrayPosition = 0;
long    timeLastPcEcho = 0;
